This is a collection of existing widgets that i changed, recolored, etc.
Thanks to the following people for making the original widgets

Felix Hageloh
Adam Courtemanche
George Irwin
Brandon Seda
Chris Johnson
Robin 'codeFareith' von den Bergen
Roland Schaer
Jose Campos

Look in the .coffee and readme files for adjustments
make sure to give ubersicht permission for location-settings in security and privacy 